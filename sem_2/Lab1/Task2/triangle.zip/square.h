#ifndef SQUARE_H
#define SQUARE_H

#include "rectangle.h"
class Square : public Rectangle
{
public:
    Square(size_t size1);

};

#endif // SQUARE_H
