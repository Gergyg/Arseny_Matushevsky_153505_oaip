#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QTimer>
#include "rectangle.h"
#include "square.h"
#include "romb.h"
#include "hexagon.h"
#include "triangle.h"
#include "pentagon.h"
#include "canvas.h"
#include "star5.h"
#include "star6.h"
#include "star8.h"
#include <string>
//QGraphicsItem* item;
int xAdd=0;
int yAdd=0;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    scene = new QGraphicsScene(0,0,600,400,this);
    ui->graphicsView->setScene(scene);
    TimerTranslate = new QTimer(this);
    connect(TimerTranslate, SIGNAL(timeout()), this, SLOT(onTranslate()));

    updTimer = new QTimer(this);
    connect(updTimer, SIGNAL(timeout()), this, SLOT(update_info()));
    updTimer->start(100);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::update_info(){
    if (item == 0){
        return;
    }

    std::string temp = "Центр масс x = " + std::to_string(xAdd+item->x()) + "\ny = " + std::to_string(yAdd+item->y());
    ui->label->setText(QString::fromStdString(temp));
    std::string temp2 = "Периметр = " + std::to_string(item->scale()*item->FigurePerimeter());
    ui->label_2->setText(QString::fromStdString(temp2));
    std::string temp3 = "Площадь = " + std::to_string(item->scale()*item->scale()*item->FigureArea());
    ui->label_3->setText(QString::fromStdString(temp3));

}
void MainWindow::on_pushButton_5_clicked()
{
    scene->removeItem(item);
    item = new Rectangle(50,100);
    item->setTransformOriginPoint(25,50);
    xAdd=25;
    yAdd=50;
    TimerTranslate->stop();

    scene->addItem(item);


}






void MainWindow::on_rotateSlider_sliderMoved(int position)
{

    if(item != nullptr) {
        item->setRotation(position);
    }
}


void MainWindow::on_scaleSlider_sliderMoved(int position)
{
    if(item != nullptr) {
        double pos=position;
        item->setScale(pos/30);
    }

}





void MainWindow::on_pushButton_9_clicked()
{
    if(item != nullptr) {
        x_position = ui->spinBox->value();
        y_position = ui->spinBox_2->value();
        m_speed_x = (x_position-item->pos().x()) / 120;
        m_speed_y = (y_position-item->pos().y()) / 120;
        TimerTranslate->start(1000/60);
    }

}
void MainWindow::onTranslate()
{
    if(fabs(item->pos().x() - x_position) > 0.01 || fabs(item->pos().y() - y_position) > 0.01)  {
        item->moveBy( m_speed_x, m_speed_y);
    } else {
        TimerTranslate->stop();
    }
}

void MainWindow::on_pushButton_3_clicked()
{
    scene->removeItem(item);
    item = new Circle(100);
    item->setTransformOriginPoint(0,50);
    xAdd=0;
    yAdd=50;
    TimerTranslate->stop();

    scene->addItem(item);
}


void MainWindow::on_pushButton_2_clicked()
{
    scene->removeItem(item);
    item = new Square(50);
    item->setTransformOriginPoint(25,25);
    xAdd=25;
    yAdd=25;
    TimerTranslate->stop();

    scene->addItem(item);
}


void MainWindow::on_pushButton_4_clicked()
{
    scene->removeItem(item);
    item = new Romb();
    item->setTransformOriginPoint(40,60);
    xAdd=40;
    yAdd=60;
    TimerTranslate->stop();

    scene->addItem(item);
}


void MainWindow::on_pushButton_7_clicked()
{
    scene->removeItem(item);
    item = new Hexagon();
    item->setTransformOriginPoint(50,50);
    xAdd=50;
    yAdd=50;
    TimerTranslate->stop();

    scene->addItem(item);
}


void MainWindow::on_pushButton_clicked()
{
    scene->removeItem(item);
    item = new triangle();
    item->setTransformOriginPoint(50,50);
    xAdd=50;
    yAdd=50;
    TimerTranslate->stop();

    scene->addItem(item);
}


void MainWindow::on_pushButton_12_clicked()
{
    canvas *Canvas = new canvas(this);
    Canvas->show();
}


void MainWindow::on_pushButton_8_clicked()
{
    scene->removeItem(item);
    item = new Pentagon();
    item->setTransformOriginPoint(50,50);
    xAdd=50;
    yAdd=50;
    TimerTranslate->stop();

    scene->addItem(item);
}


void MainWindow::on_pushButton_6_clicked()
{
    scene->removeItem(item);
    item = new Star5();
    item->setTransformOriginPoint(0,50);
    xAdd=0;
    yAdd=50;
    TimerTranslate->stop();

    scene->addItem(item);
}


void MainWindow::on_pushButton_10_clicked()
{
    scene->removeItem(item);
    item = new Star6();
    item->setTransformOriginPoint(0,50);
    xAdd=0;
    yAdd=50;
    TimerTranslate->stop();

    scene->addItem(item);
}


void MainWindow::on_pushButton_11_clicked()
{
    scene->removeItem(item);
    item = new Star8();
    item->setTransformOriginPoint(0,50);
    xAdd=0;
    yAdd=50;
    TimerTranslate->stop();

    scene->addItem(item);
}

