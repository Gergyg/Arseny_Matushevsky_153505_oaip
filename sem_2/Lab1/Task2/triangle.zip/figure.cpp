#include "figure.h"

double Figure::FigureArea()
{
    return 3247.5;

}

double Figure::FigurePerimeter()
{
    return 259.8;

}

Figure::Figure()
{

}
