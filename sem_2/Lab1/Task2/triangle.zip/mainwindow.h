#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
/*#include <QGraphicsItem>
QGraphicsItem* item;*/
#include <circle.h>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onTranslate();
    void on_pushButton_5_clicked();

    void update_info();


    void on_rotateSlider_sliderMoved(int position);

    void on_scaleSlider_sliderMoved(int position);

    void on_pushButton_9_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_clicked();

    void on_pushButton_12_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_11_clicked();

private:
    QGraphicsScene *scene;
    Ui::MainWindow *ui;
    Figure *item = nullptr;
    int x_position = 0;
    int y_position = 0;
    double m_speed_x = 0;
    double m_speed_y = 0;
    QTimer *TimerTranslate;
    QTimer *updTimer;
};
#endif // MAINWINDOW_H
