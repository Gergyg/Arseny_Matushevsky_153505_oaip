#include "square.h"

Square::Square(size_t size1) : Rectangle(size1, size1)
{
}
