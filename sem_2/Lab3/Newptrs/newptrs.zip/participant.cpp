#include "participant.h"


Participant::Participant(string s1, string s2, string s3, int i1, int i2, int i3, int i4) : country(s1), comandName(s2), fio(s3), \
    number(i1), age(i2), height(i3), weight(i4)
{

}
